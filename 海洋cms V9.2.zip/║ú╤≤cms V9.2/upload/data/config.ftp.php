<?php
$app_ftp = '0';
$app_ftphost = 'test.seacms.net';
$app_ftpuser = 'seacmstest';
$app_ftppass = 'seacmstest';
$app_ftpport = '21';
$app_ftpdir = '/';
$app_ftpurl = 'http://test.seacms.net';
$app_ftpdel = '0';
$app_updatepic = '0';
?>